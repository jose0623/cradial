<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Selectores</title>
    @livewireStyles
</head>
<body>
    <h1>Selecciona Estado y Municipio</h1>
    <livewire:selectores />

    @livewireScripts
</body>
</html>