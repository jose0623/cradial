@extends('layouts.app')

@section('template_title')
    {{ __('Update') }} Emisora Programa
@endsection

@section('content')
    <section class="content container-fluid">
        <div class="">
            <div class="col-md-12">

                <div class="card card-default">
                    <div class="card-header">
                        <span class="card-title">{{ __('Update') }} Emisora Programa</span>
                    </div>
                    <div class="card-body bg-white">
                        <form method="POST" action="{{ route('emisora-programas.update', $emisoraPrograma->id) }}"  role="form" enctype="multipart/form-data">
                            {{ method_field('PATCH') }}
                            @csrf

                            @include('emisora-programa.form')

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
