<div>

    <div class="row">
        <div class="col-md-10">
            <!-- Buscador (se mantiene igual) -->
            <div class="mb-3">
                <input 
                    type="text" 
                    wire:model.live="search" 
                    class="form-control" 
                    placeholder="Buscar por nombre o país..."
                    autofocus
                >
                <!--[if BLOCK]><![endif]--><?php if($search): ?>
                    <small class="text-muted">Buscando: "<?php echo e($search); ?>"</small>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
        <div class="col-md-2">
                 <!-- Barra de herramientas (arriba del buscador) -->
                <div class="d-flex justify-content-between mb-3">
                    <div></div> <!-- Espacio vacío para alinear a la derecha -->
                    <div class="btn-group">
                        <button wire:click="exportExcel" class="btn btn-success btn-sm">
                            <i class="fas fa-file-excel"></i> Excel
                        </button>
                        <button wire:click="exportPdf" class="btn btn-danger btn-sm">
                            <i class="fas fa-file-pdf"></i> PDF
                        </button>
                    </div>
                </div>
        </div>
    </div>
   




    

    <!-- Tabla de resultados -->
    <div class="table-responsive">
        <table class="table table-striped table-hover">
            <thead class="table-dark">
                <tr>
                    <th>N°</th> <!-- Nueva columna -->
                    <th wire:click="sortBy('name')" style="cursor: pointer;">
                        Nombre 
                        <!--[if BLOCK]><![endif]--><?php if($sortField === 'name'): ?>
                            <!--[if BLOCK]><![endif]--><?php if($sortDirection === 'asc'): ?>
                                <i class="fas fa-sort-up"></i>
                            <?php else: ?>
                                <i class="fas fa-sort-down"></i>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <?php else: ?>
                            <i class="fas fa-sort"></i>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </th>
                    <th>País</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($estados->firstItem() + $index); ?></td> <!-- Numeración consecutiva -->
                        <td><?php echo e($estado->name); ?></td>
                        <td><?php echo e($estado->paise->name ?? 'N/A'); ?></td>
                        <td>
                            <div class="btn-group" role="group">
                                <a href="<?php echo e(route('estados.show', $estado->id)); ?>" class="btn btn-sm btn-primary">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="<?php echo e(route('estados.edit', $estado->id)); ?>" class="btn btn-sm btn-success">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <button 
                                    wire:click="confirmDelete(<?php echo e($estado->id); ?>)" 
                                    class="btn btn-sm btn-danger"
                                >
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="text-center">No se encontraron resultados</td>
                    </tr>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>
    </div>

    <!-- Paginación (se mantiene igual) -->
    <div class="d-flex justify-content-between align-items-center">
        <div>
            Mostrando <?php echo e($estados->firstItem()); ?> a <?php echo e($estados->lastItem()); ?> de <?php echo e($estados->total()); ?> registros
        </div>
        <?php echo e($estados->links()); ?>

    </div>
</div><?php /**PATH C:\xampp\htdocs\cradial\resources\views/livewire/estado-search.blade.php ENDPATH**/ ?>