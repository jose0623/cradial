<div class="row padding-1 p-1">
    <div class="col-md-12">
        
        <div class="form-group mb-2 mb20">
            <label for="name" class="form-label"><?php echo e(__('Nombre')); ?></label>
            <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('name', $estado?->name)); ?>" id="name" placeholder="Nombre">
            <?php echo $errors->first('name', '<div class="invalid-feedback" role="alert"><strong>:message</strong></div>'); ?>

        </div>
        <div class="form-group mb-2 mb20">
            <label for="pais_id" class="form-label"><?php echo e(__('País')); ?></label>
           
            <select required name="pais_id" id="pais"  class="form-control " >
                <option value="">Seleccione el País</option>

                <?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   
                   <option 
                   <?php if( $item->id == $estado->pais_id ): ?>
                   selected="selected"
                   <?php endif; ?>
                   
                    
                    value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>
            <?php echo $errors->first('pais_id', '<div class="invalid-feedback" role="alert"><strong>:message</strong></div>'); ?>

        </div>

    </div>
    <div class="col-md-12 mt20 mt-2">
        <button type="submit" class="btn btn-primary"><?php echo e(__('Guardar')); ?></button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\cradial\resources\views\estado\form.blade.php ENDPATH**/ ?>