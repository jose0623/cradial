<div>

    <div class="row">
        <div class="col-md-10">
             <!-- Buscador -->
            <div class="mb-3">
                <input 
                    type="text" 
                    wire:model.live="search" 
                    class="form-control" 
                    placeholder="Buscar tipo de afiliación...">
            </div>
        </div>
        <div class="col-md-2">
            <!-- Barra de herramientas -->
            <div class="d-flex justify-content-between mb-3">
                <div class="btn-group">
                    <button wire:click="exportExcel" class="btn btn-success btn-sm">
                        <i class="fa fa-file-excel"></i> Excel
                    </button>
                    <button wire:click="exportPdf" class="btn btn-danger btn-sm">
                        <i class="fa fa-file-pdf"></i> PDF
                    </button>
                </div>
            </div>
        </div>
    </div>
   

   

    <!-- Tabla de resultados -->
    <div class="table-responsive">
        <table class="table table-striped table-hover">
            <thead class="table-dark">
                <tr>
                    <th>N°</th>
                    <th wire:click="sortBy('name')" style="cursor: pointer;">
                        Nombre 
                        <?php if($sortField === 'name'): ?>
                            <?php if($sortDirection === 'asc'): ?>
                                <i class="fa fa-sort-up"></i>
                            <?php else: ?>
                                <i class="fa fa-sort-down"></i>
                            <?php endif; ?>
                        <?php else: ?>
                            <i class="fa fa-sort"></i>
                        <?php endif; ?>
                    </th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $tipoAfiliaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $tipoAfiliacione): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($tipoAfiliaciones->firstItem() + $index); ?></td> <!-- Numeración consecutiva -->
                        <td><?php echo e($tipoAfiliacione->name); ?></td>
                        <td>
                            <form action="<?php echo e(route('tipo-afiliaciones.destroy', $tipoAfiliacione->id)); ?>" method="POST">
                                <a class="btn btn-sm btn-primary" href="<?php echo e(route('tipo-afiliaciones.show', $tipoAfiliacione->id)); ?>">
                                    <i class="fa fa-eye"></i> Ver
                                </a>
                                <a class="btn btn-sm btn-success" href="<?php echo e(route('tipo-afiliaciones.edit', $tipoAfiliacione->id)); ?>">
                                    <i class="fa fa-edit"></i> Editar
                                </a>
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm" onclick="event.preventDefault(); confirm('¿Estás seguro de eliminar?') ? this.closest('form').submit() : false;">
                                    <i class="fa fa-trash"></i> Eliminar
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="2" class="text-center">No se encontraron resultados</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Paginación -->
    <div class="d-flex justify-content-between align-items-center mt-3">
        <div>
            Mostrando <?php echo e($tipoAfiliaciones->firstItem()); ?> a <?php echo e($tipoAfiliaciones->lastItem()); ?> de <?php echo e($tipoAfiliaciones->total()); ?> registros
        </div>
        <?php echo e($tipoAfiliaciones->links()); ?>

    </div>
</div><?php /**PATH C:\xampp\htdocs\cradial\resources\views\livewire\tipo-afiliacion-search.blade.php ENDPATH**/ ?>