

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto px-4 py-8">
        <h1 class="text-2xl font-bold mb-6">Buscador de Programas de Radio</h1>
        <div class="bg-white p-6 rounded-lg shadow">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('selects-anidados');

$__html = app('livewire')->mount($__name, $__params, 'lw-1836396123-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\cradial\resources\views\selects-anidados.blade.php ENDPATH**/ ?>