<div class="row padding-1 p-1">
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-3">
                <div class="form-group mb-2 mb20">
                    <label for="nombre" class="form-label"><?php echo e(__('Nombre')); ?></label>
                    <input type="text" name="nombre" class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('nombre', $cliente?->nombre)); ?>" id="nombre" placeholder="Nombre">
                    <?php echo $errors->first('nombre', '<div class="invalid-feedback" role="alert"><strong>:message</strong></div>'); ?>

                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group mb-2 mb20">
                    <label for="telefono" class="form-label"><?php echo e(__('Telefono')); ?></label>
                    <input type="text" name="telefono" class="form-control <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('telefono', $cliente?->telefono)); ?>" id="telefono" placeholder="Telefono">
                    <?php echo $errors->first('telefono', '<div class="invalid-feedback" role="alert"><strong>:message</strong></div>'); ?>

                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group mb-2 mb20">
                    <label for="direccion" class="form-label"><?php echo e(__('Direccion')); ?></label>
                    <input type="text" name="direccion" class="form-control <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('direccion', $cliente?->direccion)); ?>" id="direccion" placeholder="Direccion">
                    <?php echo $errors->first('direccion', '<div class="invalid-feedback" role="alert"><strong>:message</strong></div>'); ?>

                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group mb-2 mb20">
                    <label for="email" class="form-label"><?php echo e(__('Email')); ?></label>
                    <input type="text" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email', $cliente?->email)); ?>" id="email" placeholder="Email">
                    <?php echo $errors->first('email', '<div class="invalid-feedback" role="alert"><strong>:message</strong></div>'); ?>

                </div>
            </div>

        </div>
        
        <div class="row">
            <div class="col-md-3">
                <div class="form-group mb-2 mb20">
                    <label for="tipo_de_documento" class="form-label"><?php echo e(__('Tipo De Documento')); ?></label>
                    <select name="tipo_de_documento" id="tipo_de_documento" class="form-control">
                        <option value="">Seleccione... </option>
                        <option <?php echo e($cliente->tipo_de_documento == 1 ? 'selected="selected"' : ''); ?> value="1">NIT</option>
                        <option <?php echo e($cliente->tipo_de_documento == 2 ? 'selected="selected"' : ''); ?> value="2">C.C</option>
                        <option <?php echo e($cliente->tipo_de_documento == 3 ? 'selected="selected"' : ''); ?> value="3">C.E.</option>
                        <option <?php echo e($cliente->tipo_de_documento == 4 ? 'selected="selected"' : ''); ?> value="4">T.I.</option>
                        <option <?php echo e($cliente->tipo_de_documento == 5 ? 'selected="selected"' : ''); ?> value="5">OTRO</option>
                    </select>
                    <?php echo $errors->first('tipo_de_documento', '<div class="invalid-feedback" role="alert"><strong>:message</strong></div>'); ?>

                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group mb-2 mb20">
                    <label for="nit" class="form-label"><?php echo e(__('Nit')); ?></label>
                    <input type="text" name="nit" class="form-control <?php $__errorArgs = ['nit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('nit', $cliente?->nit)); ?>" id="nit" placeholder="Nit">
                    <?php echo $errors->first('nit', '<div class="invalid-feedback" role="alert"><strong>:message</strong></div>'); ?>

                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group mb-2 mb20">
                    <label for="plazo_en_dias" class="form-label"><?php echo e(__('Plazo En Dias')); ?></label>
                    <input type="text" name="plazo_en_dias" class="form-control <?php $__errorArgs = ['plazo_en_dias'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('plazo_en_dias', $cliente?->plazo_en_dias)); ?>" id="plazo_en_dias" placeholder="Plazo En Dias">
                    <?php echo $errors->first('plazo_en_dias', '<div class="invalid-feedback" role="alert"><strong>:message</strong></div>'); ?>

                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group mb-2 mb20">
                    <label for="tipo_cliente_id" class="form-label"><?php echo e(__('Tipo Cliente')); ?></label>
        
                    <select required name="tipo_cliente_id" id="tipo_cliente_id"  class="form-control " >
                        <option value="">Seleccione...</option>
        
                        <?php $__currentLoopData = $tipocliente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           
                        <option 
                        <?php if( $item->id == $cliente->tipo_cliente_id ): ?>
                        selected="selected"
                        <?php endif; ?>
                           
                            
                            value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
                    </select>
                    <?php echo $errors->first('tipo_cliente_id', '<div class="invalid-feedback" role="alert"><strong>:message</strong></div>'); ?>

                </div>
            </div>
           
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group mb-2 mb20">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('selectores', ['municipioId' => $cliente->municipio_id]);

$__html = app('livewire')->mount($__name, $__params, 'lw-1409488896-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>
            </div>
        
            <div class="col-md-3">
                <div class="form-group mb-2 mb20">
                    <label for="fax" class="form-label"><?php echo e(__('Fax')); ?></label>
                    <input type="text" name="fax" class="form-control <?php $__errorArgs = ['fax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('fax', $cliente?->fax)); ?>" id="fax" placeholder="Fax">
                    <?php echo $errors->first('fax', '<div class="invalid-feedback" role="alert"><strong>:message</strong></div>'); ?>

                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group mb-2 mb20">
                    <label for="vendedor_id" class="form-label"><?php echo e(__('Vendedor')); ?></label>
                   
                    <select required name="vendedor_id" id="vendedor_id"  class="form-control " >
                        <option value="">Seleccione...</option>
        
                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           
                        <option 
                        <?php if( $item->id == $cliente->vendedor_id ): ?>
                        selected="selected"
                        <?php endif; ?>
                           
                            
                            value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
                    </select>
        
        
                   
                    <?php echo $errors->first('vendedor_id', '<div class="invalid-feedback" role="alert"><strong>:message</strong></div>'); ?>

                </div>
            </div>

        </div>
        
        <div class="row">
            <div class="col-md-12">

                <div class="form-group mb-2 mb20">
                    <label for="tipo_cliente_id" class="form-label"><?php echo e(__('Regimen')); ?></label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="comun" id="comun" value="1" 
                    <?php if(old('comun', $cliente->comun ?? false)): ?> checked <?php endif; ?>>
                    <label class="form-check-label">Comun</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="simplificado" id="simplificado" value="1" 
                    <?php if(old('simplificado', $cliente->simplificado ?? false)): ?> checked <?php endif; ?>>
                    <label class="form-check-label">Simplificado</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="gca" id="gca" value="1" 
                    <?php if(old('gca', $cliente->gca ?? false)): ?> checked <?php endif; ?>>
                    <label class="form-check-label">Gran contribuyente autoretenedor</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="gc" id="gc" value="1" 
                    <?php if(old('gc', $cliente->gc ?? false)): ?> checked <?php endif; ?>>
                    <label class="form-check-label">Gran contribuyente</label>
                </div>

            </div>
        </div>

<br>

    </div>
    <div class="col-md-12 mt20 mt-2">
        <button type="submit" class="btn btn-primary"><?php echo e(__('Submit')); ?></button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\cradial\resources\views\cliente\form.blade.php ENDPATH**/ ?>