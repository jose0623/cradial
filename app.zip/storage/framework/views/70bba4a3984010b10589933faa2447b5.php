<div>
    <!-- Barra de herramientas -->
    <div class="d-flex justify-content-between mb-3">
        <div>
            <select wire:model.live="perPage" class="form-select form-select-sm">
                <option value="10">10 por página</option>
                <option value="20">20 por página</option>
                <option value="50">50 por página</option>
                <option value="100">100 por página</option>
            </select>
        </div>
        <div class="btn-group">
            <button wire:click="exportExcel" class="btn btn-success btn-sm">
                <i class="fa fa-file-excel"></i> Excel
            </button>
            <button wire:click="exportPdf" class="btn btn-danger btn-sm">
                <i class="fa fa-file-pdf"></i> PDF
            </button>
        </div>
    </div>

    <!-- Buscador -->
    <div class="mb-3">
        <input 
            type="text" 
            wire:model.live="search" 
            class="form-control" 
            placeholder="Buscar fiestas por nombre, fecha o emisora..."
        >
    </div>

    <!-- Tabla de resultados -->
    <div class="table-responsive">
        <table class="table table-striped table-hover">
            <thead class="table-dark">
                <tr>
                    <th>Nº</th>
                    <th wire:click="sortBy('nombre')" style="cursor: pointer;">
                        Nombre
                        <?php if($sortField === 'nombre'): ?>
                            <?php if($sortDirection === 'asc'): ?>
                                <i class="fa fa-sort-up"></i>
                            <?php else: ?>
                                <i class="fa fa-sort-down"></i>
                            <?php endif; ?>
                        <?php else: ?>
                            <i class="fa fa-sort"></i>
                        <?php endif; ?>
                    </th>
                    <th wire:click="sortBy('fecha')" style="cursor: pointer;">
                        Fecha
                        <?php if($sortField === 'fecha'): ?>
                            <?php if($sortDirection === 'asc'): ?>
                                <i class="fa fa-sort-up"></i>
                            <?php else: ?>
                                <i class="fa fa-sort-down"></i>
                            <?php endif; ?>
                        <?php else: ?>
                            <i class="fa fa-sort"></i>
                        <?php endif; ?>
                    </th>
                    <th>Emisora</th>
                    <th style="text-align: right;">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $fiestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $fiesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($fiestas->firstItem() + $index); ?></td>
                        <td><?php echo e($fiesta->nombre); ?></td>
                        <td><?php echo e($fiesta->fecha); ?></td>
                        <td><?php echo e($fiesta->emisora->name ?? 'N/A'); ?></td>
                        <td style="min-width: 240px;text-align: right;" >
                            <form action="<?php echo e(route('emisora.fiestas.destroy', $fiesta->id)); ?>" method="POST"  style="margin: 0;">
                                <a class="btn btn-sm btn-primary " href="<?php echo e(route('emisora.fiestas.show', $fiesta->id)); ?>">
                                    <i class="fa fa-fw fa-eye"></i>
                                </a>
                                <a class="btn btn-sm btn-success" href="<?php echo e(route('emisora.fiestas.edit', $fiesta->id)); ?>">
                                    <i class="fa fa-fw fa-edit"></i>
                                </a>
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm" onclick="event.preventDefault(); confirm('¿Estás seguro de eliminar?') ? this.closest('form').submit() : false;">
                                    <i class="fa fa-fw fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="text-center">No se encontraron fiestas</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Paginación -->
    <div class="d-flex justify-content-between align-items-center mt-3">
        <div>
            Mostrando <?php echo e($fiestas->firstItem()); ?> a <?php echo e($fiestas->lastItem()); ?> de <?php echo e($fiestas->total()); ?> registros
        </div>
        <?php echo e($fiestas->links()); ?>

    </div>
</div><?php /**PATH C:\xampp\htdocs\cradial\resources\views\livewire\fiesta-search.blade.php ENDPATH**/ ?>