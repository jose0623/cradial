<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title><?php echo e($title); ?></title>
    <style>
        body { font-family: helvetica, sans-serif; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th { background-color: #f2f2f2; text-align: left; padding: 8px; font-weight: bold; }
        td { padding: 8px; border: 1px solid #ddd; }
        .header { text-align: center; margin-bottom: 20px; }
        .title { font-size: 18px; font-weight: bold; }
        .subtitle { font-size: 14px; color: #555; }
    </style>
</head>
<body>
    <div class="header">
        <div class="title"><?php echo e($title); ?></div>
        <div class="subtitle">Generado el: <?php echo e(now()->format('d/m/Y H:i')); ?></div>
    </div>
    
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Nombre</th>
                <th>Fecha</th>
                <th>Emisora</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $fiestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $fiesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($fiesta['nombre']); ?></td>
                <td><?php echo e($fiesta['fecha']); ?></td>
                <td><?php echo e($fiesta['emisora']); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html><?php /**PATH C:\xampp\htdocs\cradial\resources\views\exports\fiestas-pdf.blade.php ENDPATH**/ ?>