<div class="row padding-1 p-1">
    <div class="col-md-12">
        
        <div class="form-group mb-2 mb20">
            <label for="id_emisora" class="form-label"><?php echo e(__('Emisora Id')); ?></label>
            <input type="text" name="id_emisora" class="form-control <?php $__errorArgs = ['id_emisora'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('id_emisora', $cobertura?->id_emisora)); ?>" id="id_emisora" placeholder="Emisora Id">
            <?php echo $errors->first('id_emisora', '<div class="invalid-feedback" role="alert"><strong>:message</strong></div>'); ?>

        </div>
        <div class="form-group mb-2 mb20">
            <label for="municipio_id" class="form-label"><?php echo e(__('Municipio Id')); ?></label>
            <input type="text" name="municipio_id" class="form-control <?php $__errorArgs = ['municipio_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('municipio_id', $cobertura?->municipio_id)); ?>" id="municipio_id" placeholder="Municipio Id">
            <?php echo $errors->first('municipio_id', '<div class="invalid-feedback" role="alert"><strong>:message</strong></div>'); ?>

        </div>

    </div>
    <div class="col-md-12 mt20 mt-2">
        <button type="submit" class="btn btn-primary"><?php echo e(__('Submit')); ?></button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\cradial\resources\views\cobertura\form.blade.php ENDPATH**/ ?>