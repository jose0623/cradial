<?php $__env->startSection('template_title'); ?>
    Coberturas
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<br>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">

                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('municipio-form', ['id_emisora' => $id_emisora]);

$__html = app('livewire')->mount($__name, $__params, 'lw-1098205709-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

                </div>
            </div>
        </div>
    </div>

    <style>
        .alert.alert-success.m-4 {
            margin: 0 0 20px !important;
        }
    </style>
   
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\cradial\resources\views\cobertura\index.blade.php ENDPATH**/ ?>