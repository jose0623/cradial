<?php $__env->startSection('template_title'); ?>
    <?php echo e($user->name ?? __('Show') . " " . __('User')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
                        <div class="float-left">
                            <span class="card-title"><?php echo e(__('Ver')); ?> User</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary btn-sm" href="<?php echo e(route('users.index')); ?>"> <?php echo e(__('Regresar')); ?></a>
                        </div>
                    </div>

                    <div class="card-body bg-white">
                        
                                <div class="form-group mb-2 mb20">
                                    <strong>Name:</strong>
                                    <?php echo e($user->name); ?>

                                </div>
                                <div class="form-group mb-2 mb20">
                                    <strong>Email:</strong>
                                    <?php echo e($user->email); ?>

                                </div>
                                <div class="form-group mb-2 mb20">
                                    <strong>User Type:</strong>
                                    <?php echo e($user->user_type); ?>

                                </div>
                                <div class="form-group mb-2 mb20">
                                    <strong>Two Factor Secret:</strong>
                                    <?php echo e($user->two_factor_secret); ?>

                                </div>
                                <div class="form-group mb-2 mb20">
                                    <strong>Two Factor Recovery Codes:</strong>
                                    <?php echo e($user->two_factor_recovery_codes); ?>

                                </div>
                                <div class="form-group mb-2 mb20">
                                    <strong>Two Factor Confirmed At:</strong>
                                    <?php echo e($user->two_factor_confirmed_at); ?>

                                </div>
                                <div class="form-group mb-2 mb20">
                                    <strong>Current Team Id:</strong>
                                    <?php echo e($user->current_team_id); ?>

                                </div>
                                <div class="form-group mb-2 mb20">
                                    <strong>Profile Photo Path:</strong>
                                    <?php echo e($user->profile_photo_path); ?>

                                </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\cradial\resources\views\user\show.blade.php ENDPATH**/ ?>