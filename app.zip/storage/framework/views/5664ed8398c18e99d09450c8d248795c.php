<!DOCTYPE html>
<html>
<head>
    <title>Reporte Emisora - <?php echo e($emisora->name); ?></title>
    <style>
        body { font-family: sans-serif; font-size: 10pt; }
        .container { width: 100%; }
        .row { display: flex; flex-wrap: wrap; margin-bottom: 10px; }
        .col-md-3 { width: 25%; padding-right: 10px; }
        .col-md-6 { width: 50%; padding-right: 10px; }
        .col-md-12 { width: 100%; margin-bottom: 10px; }
        strong { font-weight: bold; }
        hr { margin-top: 20px; margin-bottom: 20px; border: 0; border-top: 1px solid #ccc; }
        .list-group { list-style: none; padding: 0; }
        .list-group-item { border: 1px solid #ddd; margin-bottom: 5px; padding: 8px; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Hoja de Vida de la Emisora - <?php echo e($emisora->name); ?></h2>
        <hr>

        <h4>Información General</h4>
        <div class="row">
            <div class="col-md-3"><strong>Nombre:</strong> <?php echo e($emisora->name); ?></div>
            <div class="col-md-3"><strong>Potencia:</strong> <?php echo e($emisora->potencia); ?></div>
            <div class="col-md-3"><strong>Dial:</strong> <?php echo e($emisora->dial); ?></div>
            <div class="col-md-3"><strong>Tipo Emisora:</strong> <?php echo e($emisora->tipoEmisora->name); ?></div>
        </div>
        <div class="row">
            <div class="col-md-3"><strong>Tipo Documento:</strong>
                <?php if($emisora->tipo_documento == 1): ?> NIT <?php endif; ?>
                <?php if($emisora->tipo_documento == 2): ?> C.C <?php endif; ?>
                <?php if($emisora->tipo_documento == 3): ?> C.E <?php endif; ?>
                <?php if($emisora->tipo_documento == 4): ?> T.I <?php endif; ?>
                <?php if($emisora->tipo_documento == 5): ?> OTRO <?php endif; ?>
            </div>
            <div class="col-md-3"><strong>Identificación:</strong> <?php echo e($emisora->identificacion); ?></div>
            <div class="col-md-3"><strong>Municipio:</strong> <?php echo e($emisora->municipio->name); ?></div>
            <div class="col-md-3"><strong>Dirección:</strong> <?php echo e($emisora->direccion); ?></div>
        </div>
        <hr>

        <h4>Características</h4>
        <div class="row">
            <div class="col-md-3"><strong>Tiene Real Audio:</strong> <?php echo e($emisora->tiene_real_audio == 1 ? 'Si' : 'No'); ?></div>
            <div class="col-md-3"><strong>Real Audio:</strong> <?php echo e($emisora->real_audio); ?></div>
            <div class="col-md-6"><strong>Descripción Real Audio:</strong> <?php echo e($emisora->descripcion_real_audio); ?></div>
        </div>
        <div class="row">
            <div class="col-md-3"><strong>Utiliza Remoto:</strong> <?php echo e($emisora->utiliza_remoto == 1 ? 'Si' : 'No'); ?></div>
            <div class="col-md-3"><strong>Tarifa Remoto:</strong> <?php echo e($emisora->tarifa_remoto); ?></div>
            <div class="col-md-3"><strong>Tiempo del Remoto:</strong> <?php echo e($emisora->tiempo_remoto); ?></div>
            <div class="col-md-3"><strong>Descripción del Remoto:</strong> <?php echo e($emisora->descripcion_remoto); ?></div>
        </div>
        <div class="row">
            <div class="col-md-3"><strong>Utiliza Perifoneo:</strong> <?php echo e($emisora->utiliza_perifoneo == 1 ? 'Si' : 'No'); ?></div>
            <div class="col-md-3"><strong>Tarifa Perifoneo:</strong> <?php echo e($emisora->tarifa_perifoneo); ?></div>
            <div class="col-md-3"><strong>Tiempo del Perifoneo:</strong> <?php echo e($emisora->tiempo_perifoneo); ?></div>
            <div class="col-md-3"><strong>Descripción del Perifoneo:</strong> <?php echo e($emisora->descripcion_perifoneo); ?></div>
        </div>
        <div class="row">
            <div class="col-md-3"><strong>Web:</strong> <?php echo e($emisora->web); ?></div>
            <div class="col-md-3"><strong>Clase de Pauta:</strong> <?php echo e($emisora->clase_pauta); ?></div>
            <div class="col-md-3"><strong>Licencia Funcionamiento:</strong> <?php echo e($emisora->licencia_funcionamiento); ?></div>
            <div class="col-md-3"><strong>Afiliación:</strong> <?php echo e($emisora->tipoAfiliacione->name); ?></div>
        </div>
        <div class="row">
            <div class="col-md-3"><strong>Cantidad Mínima:</strong> <?php echo e($emisora->cantidad_minima); ?></div>
            <div class="col-md-3"><strong>Iva:</strong> <?php echo e($emisora->iva == 1 ? 'Si' : 'No'); ?></div>
            <div class="col-md-3"><strong>Nombre Periódico:</strong> <?php echo e($emisora->nombre_periodico); ?></div>
            <div class="col-md-3"><strong>Nombre Canal Televisión:</strong> <?php echo e($emisora->nombre_canal_television); ?></div>
        </div>
        <hr>

        <h4>Contactos</h4>
        <div class="row">
            <div class="col-md-3"><strong>Facebook:</strong> <?php echo e($emisora->facebook); ?></div>
            <div class="col-md-3"><strong>Instagram:</strong> <?php echo e($emisora->instagram); ?></div>
            <div class="col-md-3"><strong>Tiktok:</strong> <?php echo e($emisora->tiktok); ?></div>
            <div class="col-md-3"><strong>Email:</strong> <?php echo e($emisora->email); ?></div>
        </div>
        <div class="row">
            <div class="col-md-3"><strong>Email 2:</strong> <?php echo e($emisora->email2); ?></div>
            <div class="col-md-3"><strong>Email 3:</strong> <?php echo e($emisora->email3); ?></div>
            <div class="col-md-3"><strong>Teléfono:</strong> <?php echo e($emisora->telefono1); ?></div>
            <div class="col-md-3"><strong>Celular:</strong> <?php echo e($emisora->celular); ?></div>
        </div>
        <hr>
        <h4>Responsables</h4>
        <div class="row">
            <div class="col-md-3"><strong>Gerente:</strong> <?php echo e($emisora->gerente); ?></div>
            <div class="col-md-3"><strong>Teléfono Gerente:</strong> <?php echo e($emisora->telefono_gerente); ?></div>
            <div class="col-md-3"><strong>Director Noticias:</strong> <?php echo e($emisora->director_noticias); ?></div>
            <div class="col-md-3"><strong>Teléfono Director Noticias:</strong> <?php echo e($emisora->telefono_director_noticias); ?></div>
        </div>
        <div class="row">
            <div class="col-md-3"><strong>Encargado de Pauta:</strong> <?php echo e($emisora->encargado_pauta); ?></div>
            <div class="col-md-3"><strong>Teléfono Encargado de Pauta:</strong> <?php echo e($emisora->telefono_encargado_pauta); ?></div>
            <div class="col-md-3"><strong>Representante Legal:</strong> <?php echo e($emisora->representante_legal); ?></div>
            <div class="col-md-3"><strong>Teléfono Representante Legal:</strong> <?php echo e($emisora->telefono_representante_legal); ?></div>
        </div>
        <hr>

        <h4>Observaciones</h4>
        <div class="row">
            <div class="col-md-12"><?php echo e($emisora->observaciones); ?></div>
        </div>
        <hr>

        <h4>Coberturas</h4>
        <?php if($coberturas->count() > 0): ?>
            <ul class="list-group">
                <?php $__currentLoopData = $coberturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cobertura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item">
                        <strong>Municipio:</strong> <?php echo e($cobertura->municipio->name); ?> |
                        <strong>Dpto:</strong> <?php echo e($cobertura->municipio->estado->name); ?>

                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php else: ?>
            <p>No hay coberturas registradas para esta emisora.</p>
        <?php endif; ?>
        <hr>

        <h4>Fiestas</h4>
        <?php if($fiestas->count() > 0): ?>
            <ul class="list-group">
                <?php $__currentLoopData = $fiestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fiesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item">
                        <strong>Nombre:</strong> <?php echo e($fiesta->nombre); ?> |
                        <strong>Fecha:</strong> <?php echo e($fiesta->fecha); ?>

                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php else: ?>
            <p>No hay fiestas registradas para esta emisora.</p>
        <?php endif; ?>
        <hr>

        <h4>Programas</h4>
        <?php if($programas->count() > 0): ?>
            <ul class="list-group">
                <?php $__currentLoopData = $programas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item">
                        <strong>Nombre:</strong> <?php echo e($programa->nombre_programa); ?> |
                        <strong>Locutor:</strong> <?php echo e($programa->nombre_locutor); ?> |
                        <strong>Tipo:</strong> <?php echo e($programa->tipoPrograma->name); ?> |
                        <strong>Horario:</strong> <?php echo e($programa->horario); ?> |
                        <strong>Tarifa:</strong> <?php echo e($programa->costo); ?> |
                        <strong>Días:</strong>
                        <small>
                            <?php echo e($programa->lunes ? 'LU ' : ''); ?>

                            <?php echo e($programa->martes ? 'MA ' : ''); ?>

                            <?php echo e($programa->miercoles ? 'MI ' : ''); ?>

                            <?php echo e($programa->jueves ? 'JU ' : ''); ?>

                            <?php echo e($programa->viernes ? 'VI ' : ''); ?>

                            <?php echo e($programa->sabado ? 'SA ' : ''); ?>

                            <?php echo e($programa->domingo ? 'DO' : ''); ?>

                        </small>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php else: ?>
            <p>No hay programas registrados para esta emisora.</p>
        <?php endif; ?>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\cradial\resources\views\pdfs\emisora.blade.php ENDPATH**/ ?>