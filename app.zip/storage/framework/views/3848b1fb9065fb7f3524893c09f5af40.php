<table>
    <thead>
        <tr>
            <th colspan="4">Información General de la Emisora</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td><strong>Nombre:</strong></td>
            <td><?php echo e($emisora->name); ?></td>
            <td><strong>Potencia:</strong></td>
            <td><?php echo e($emisora->potencia); ?></td>
        </tr>
        <tr>
            <td><strong>Dial:</strong></td>
            <td><?php echo e($emisora->dial); ?></td>
            <td><strong>Tipo Emisora:</strong></td>
            <td><?php echo e($emisora->tipoEmisora->name); ?></td>
        </tr>
        <tr>
            <td><strong>Tipo Documento:</strong></td>
            <td>
                <?php if($emisora->tipo_documento == 1): ?> NIT <?php endif; ?>
                <?php if($emisora->tipo_documento == 2): ?> C.C <?php endif; ?>
                <?php if($emisora->tipo_documento == 3): ?> C.E. <?php endif; ?>
                <?php if($emisora->tipo_documento == 4): ?> T.I. <?php endif; ?>
                <?php if($emisora->tipo_documento == 5): ?> OTRO <?php endif; ?>
            </td>
            <td><strong>Identificación:</strong></td>
            <td><?php echo e($emisora->identificacion); ?></td>
        </tr>
        <tr>
            <td><strong>Municipio:</strong></td>
            <td><?php echo e($emisora->municipio->name); ?></td>
            <td><strong>Dirección:</strong></td>
            <td><?php echo e($emisora->direccion); ?></td>
        </tr>
    </tbody>
</table>

<br>

<table>
    <thead>
        <tr>
            <th colspan="4">Características</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td><strong>Tiene Real Audio:</strong></td>
            <td><?php echo e($emisora->tiene_real_audio == 1 ? 'Si' : 'No'); ?></td>
            <td><strong>Real Audio:</strong></td>
            <td><?php echo e($emisora->real_audio); ?></td>
        </tr>
        <tr>
            <td><strong>Descripción Real Audio:</strong></td>
            <td colspan="3"><?php echo e($emisora->descripcion_real_audio); ?></td>
        </tr>
        <tr>
            <td><strong>Utiliza Remoto:</strong></td>
            <td><?php echo e($emisora->utiliza_remoto == 1 ? 'Si' : 'No'); ?></td>
            <td><strong>Tarifa Remoto:</strong></td>
            <td><?php echo e($emisora->tarifa_remoto); ?></td>
        </tr>
        <tr>
            <td><strong>Tiempo del Remoto:</strong></td>
            <td><?php echo e($emisora->tiempo_remoto); ?></td>
            <td><strong>Descripción del Remoto:</strong></td>
            <td><?php echo e($emisora->descripcion_remoto); ?></td>
        </tr>
        <tr>
            <td><strong>Utiliza Perifoneo:</strong></td>
            <td><?php echo e($emisora->utiliza_perifoneo == 1 ? 'Si' : 'No'); ?></td>
            <td><strong>Tarifa Perifoneo:</strong></td>
            <td><?php echo e($emisora->tarifa_perifoneo); ?></td>
        </tr>
        <tr>
            <td><strong>Tiempo del Perifoneo:</strong></td>
            <td><?php echo e($emisora->tiempo_perifoneo); ?></td>
            <td><strong>Descripción del Perifoneo:</strong></td>
            <td><?php echo e($emisora->descripcion_perifoneo); ?></td>
        </tr>
        <tr>
            <td><strong>Web:</strong></td>
            <td><?php echo e($emisora->web); ?></td>
            <td><strong>Clase de Pauta:</strong></td>
            <td><?php echo e($emisora->clase_pauta); ?></td>
        </tr>
        <tr>
            <td><strong>Licencia Funcionamiento:</strong></td>
            <td><?php echo e($emisora->licencia_funcionamiento); ?></td>
            <td><strong>Afiliación:</strong></td>
            <td><?php echo e($emisora->tipoAfiliacione->name); ?></td>
        </tr>
        <tr>
            <td><strong>Cantidad Mínima:</strong></td>
            <td><?php echo e($emisora->cantidad_minima); ?></td>
            <td><strong>Iva:</strong></td>
            <td><?php echo e($emisora->iva == 1 ? 'Si' : 'No'); ?></td>
        </tr>
        <tr>
            <td><strong>Nombre Periódico:</strong></td>
            <td><?php echo e($emisora->nombre_periodico); ?></td>
            <td><strong>Nombre Canal Televisión:</strong></td>
            <td><?php echo e($emisora->nombre_canal_television); ?></td>
        </tr>
    </tbody>
</table>

<br>

<table>
    <thead>
        <tr>
            <th colspan="4">Contactos</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td><strong>Facebook:</strong></td>
            <td><?php echo e($emisora->facebook); ?></td>
            <td><strong>Instagram:</strong></td>
            <td><?php echo e($emisora->instagram); ?></td>
        </tr>
        <tr>
            <td><strong>Tiktok:</strong></td>
            <td><?php echo e($emisora->tiktok); ?></td>
            <td><strong>Email:</strong></td>
            <td><?php echo e($emisora->email); ?></td>
        </tr>
        <tr>
            <td><strong>Email 2:</strong></td>
            <td><?php echo e($emisora->email2); ?></td>
            <td><strong>Email 3:</strong></td>
            <td><?php echo e($emisora->email3); ?></td>
        </tr>
        <tr>
            <td><strong>Teléfono:</strong></td>
            <td><?php echo e($emisora->telefono1); ?></td>
            <td><strong>Celular:</strong></td>
            <td><?php echo e($emisora->celular); ?></td>
        </tr>
    </tbody>
</table>

<br>

<table>
    <thead>
        <tr>
            <th colspan="4">Responsables</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td><strong>Gerente:</strong></td>
            <td><?php echo e($emisora->gerente); ?></td>
            <td><strong>Teléfono Gerente:</strong></td>
            <td><?php echo e($emisora->telefono_gerente); ?></td>
        </tr>
        <tr>
            <td><strong>Director Noticias:</strong></td>
            <td><?php echo e($emisora->director_noticias); ?></td>
            <td><strong>Teléfono Director Noticias:</strong></td>
            <td><?php echo e($emisora->telefono_director_noticias); ?></td>
        </tr>
        <tr>
            <td><strong>Encargado de Pauta:</strong></td>
            <td><?php echo e($emisora->encargado_pauta); ?></td>
            <td><strong>Teléfono Encargado de Pauta:</strong></td>
            <td><?php echo e($emisora->telefono_encargado_pauta); ?></td>
        </tr>
        <tr>
            <td><strong>Representante Legal:</strong></td>
            <td><?php echo e($emisora->representante_legal); ?></td>
            <td><strong>Teléfono Representante Legal:</strong></td>
            <td><?php echo e($emisora->telefono_representante_legal); ?></td>
        </tr>
    </tbody>
</table>

<br>

<table>
    <thead>
        <tr>
            <th>Observaciones</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td><?php echo e($emisora->observaciones); ?></td>
        </tr>
    </tbody>
</table>

<br>

<table>
    <thead>
        <tr>
            <th colspan="2">Coberturas</th>
        </tr>
        <tr>
            <th>Municipio</th>
            <th>Departamento</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $coberturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cobertura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($cobertura->municipio->name); ?></td>
                <td><?php echo e($cobertura->municipio->estado->name); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="2">No hay coberturas registradas.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<br>

<table>
    <thead>
        <tr>
            <th colspan="2">Fiestas</th>
        </tr>
        <tr>
            <th>Nombre</th>
            <th>Fecha</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $fiestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fiesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($fiesta->nombre); ?></td>
                <td><?php echo e($fiesta->fecha); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="2">No hay fiestas registradas.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<br>

<table>
    <thead>
        <tr>
            <th>Nombre Programa</th>
            <th>Locutor</th>
            <th>Tipo</th>
            <th>Horario</th>
            <th>Tarifa</th>
            <th>Días</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $programas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($programa->nombre_programa); ?></td>
                <td><?php echo e($programa->nombre_locutor); ?></td>
                <td><?php echo e($programa->tipoPrograma->name); ?></td>
                <td><?php echo e($programa->horario); ?></td>
                <td><?php echo e($programa->costo); ?></td>
                <td>
                    <small>
                        <?php echo e($programa->lunes ? 'LU ' : ''); ?>

                        <?php echo e($programa->martes ? 'MA ' : ''); ?>

                        <?php echo e($programa->miercoles ? 'MI ' : ''); ?>

                        <?php echo e($programa->jueves ? 'JU ' : ''); ?>

                        <?php echo e($programa->viernes ? 'VI ' : ''); ?>

                        <?php echo e($programa->sabado ? 'SA ' : ''); ?>

                        <?php echo e($programa->domingo ? 'DO' : ''); ?>

                    </small>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="6">No hay programas registrados.</td></tr>
        <?php endif; ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\cradial\resources\views\exports\emisora.blade.php ENDPATH**/ ?>