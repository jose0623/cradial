<div>

    <div class="card-header">
        <div style="display: flex; justify-content: space-between; align-items: center;">

            <?php $__currentLoopData = $emisoras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emisora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($emisora->id == $id_emisora): ?>
                <span id="card_title">
                    Cobertura de la Emisora: <b> <?php echo e($emisora->name); ?> </b>
                </span>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <?php $__currentLoopData = $emisoras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emisora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
    <br>
    <br>

    <div class="container">
        <div class="row">
            <div class="col-md-12">

                <?php if(session()->has('message')): ?>
                <div class="alert alert-success m-4">
                    <p> <?php echo e(session('message')); ?></p>
                </div>
                <?php endif; ?>

                <form wire:submit.prevent="save">
                
                        <div class="row">
                            <div class="col-md-12">
                                <div>
                                    <label for="estado_id">Estado:</label>
                                    <select class="form-control" wire:model.live="estado_id" id="estado_id">
                                        <option value="">Selecciona un estado</option>
                                        <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($estado->id); ?>"><?php echo e($estado->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-12">
                
                                <div>
                                    <br>
                                    <label for="municipios">Municipios:</label>
                                    <select class="form-control" wire:model="selectedMunicipios" id="municipios" multiple>
                                        <?php $__currentLoopData = $municipios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($municipio->id); ?>" <?php echo e(in_array($municipio->id, $selectedMunicipiosIds) ? 'disabled' : ''); ?>>
                                                <?php echo e($municipio->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                
                            </div>
                            <div class="col-md-12">
                                <br>
                                <button  class="btn btn-primary" type="submit">Guardar</button>
                            </div>
                        </div>
                
                    </form>
                  

                  
            </div>
           
            <div class="col-md-12">
                <br>
                <br>
                <h2>Registros</h2>
                <?php
                    $itenss = 1;
                ?>
                <div class="card-body bg-white">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead class="thead">
                                <tr>
            
                                <th>No</th>
                                <th >Estado</th>
                                <th >Municipios</th>
                                <th>Porcentaje de Cobertura </th>
                                <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>

                                
                                <?php $__currentLoopData = $regiones->groupBy('municipio.estado_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado_id => $regiones_por_estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $totalMunicipios = \App\Models\Municipio::where('estado_id', $estado_id)->count();
                                    $seleccionados = $regiones_por_estado->count();
                                    $porcentaje = $totalMunicipios ? ($seleccionados / $totalMunicipios) * 100 : 0;
                                    ?>
                                
                                <tr>
                                    <td> <?php echo e($itenss); ?> </td>
                                    <td colspan="1"><strong><?php echo e($estados->find($estado_id)->name ?? 'Desconocido'); ?></strong></td>
                                    <td> - </td>
                                    <td> <?php echo e(number_format($porcentaje, 2)); ?>% </td>
                                    <td> - </td>
                                </tr>
                                
                                <?php $__currentLoopData = $regiones_por_estado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td><?php echo e($region->municipio->name); ?></td>
                                        <td></td>
                                        <td>
                                            <button class="btn btn-danger" wire:click="delete(<?php echo e($region->id); ?>)">Eliminar</button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $itenss++;
                                ?> 
                                    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>


            </div>
        </div>
    </div>

   





</div>
<?php /**PATH C:\xampp\htdocs\cradial\resources\views\livewire\municipio-form.blade.php ENDPATH**/ ?>