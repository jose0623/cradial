<div class="row padding-1 p-1">
    <div class="col-md-12">
        
        <div class="form-group mb-2 mb20">
            <label for="name" class="form-label"><?php echo e(__('Name')); ?></label>
            <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('name', $user?->name)); ?>" id="name" placeholder="Name">
            <?php echo $errors->first('name', '<div class="invalid-feedback" role="alert"><strong>:message</strong></div>'); ?>

        </div>
        <div class="form-group mb-2 mb20">
            <label for="email" class="form-label"><?php echo e(__('Email')); ?></label>
            <input type="text" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email', $user?->email)); ?>" id="email" placeholder="Email">
            <?php echo $errors->first('email', '<div class="invalid-feedback" role="alert"><strong>:message</strong></div>'); ?>

        </div>
        <div class="form-group mb-2 mb20">
            <label for="user_type" class="form-label"><?php echo e(__('User Type')); ?></label>
            <input type="text" name="user_type" class="form-control <?php $__errorArgs = ['user_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('user_type', $user?->user_type)); ?>" id="user_type" placeholder="User Type">
            <?php echo $errors->first('user_type', '<div class="invalid-feedback" role="alert"><strong>:message</strong></div>'); ?>

        </div>
        <div class="form-group mb-2 mb20">
            <label for="two_factor_secret" class="form-label"><?php echo e(__('Two Factor Secret')); ?></label>
            <input type="text" name="two_factor_secret" class="form-control <?php $__errorArgs = ['two_factor_secret'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('two_factor_secret', $user?->two_factor_secret)); ?>" id="two_factor_secret" placeholder="Two Factor Secret">
            <?php echo $errors->first('two_factor_secret', '<div class="invalid-feedback" role="alert"><strong>:message</strong></div>'); ?>

        </div>
        <div class="form-group mb-2 mb20">
            <label for="two_factor_recovery_codes" class="form-label"><?php echo e(__('Two Factor Recovery Codes')); ?></label>
            <input type="text" name="two_factor_recovery_codes" class="form-control <?php $__errorArgs = ['two_factor_recovery_codes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('two_factor_recovery_codes', $user?->two_factor_recovery_codes)); ?>" id="two_factor_recovery_codes" placeholder="Two Factor Recovery Codes">
            <?php echo $errors->first('two_factor_recovery_codes', '<div class="invalid-feedback" role="alert"><strong>:message</strong></div>'); ?>

        </div>
        <div class="form-group mb-2 mb20">
            <label for="two_factor_confirmed_at" class="form-label"><?php echo e(__('Two Factor Confirmed At')); ?></label>
            <input type="text" name="two_factor_confirmed_at" class="form-control <?php $__errorArgs = ['two_factor_confirmed_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('two_factor_confirmed_at', $user?->two_factor_confirmed_at)); ?>" id="two_factor_confirmed_at" placeholder="Two Factor Confirmed At">
            <?php echo $errors->first('two_factor_confirmed_at', '<div class="invalid-feedback" role="alert"><strong>:message</strong></div>'); ?>

        </div>
        <div class="form-group mb-2 mb20">
            <label for="current_team_id" class="form-label"><?php echo e(__('Current Team Id')); ?></label>
            <input type="text" name="current_team_id" class="form-control <?php $__errorArgs = ['current_team_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('current_team_id', $user?->current_team_id)); ?>" id="current_team_id" placeholder="Current Team Id">
            <?php echo $errors->first('current_team_id', '<div class="invalid-feedback" role="alert"><strong>:message</strong></div>'); ?>

        </div>
        <div class="form-group mb-2 mb20">
            <label for="profile_photo_path" class="form-label"><?php echo e(__('Profile Photo Path')); ?></label>
            <input type="text" name="profile_photo_path" class="form-control <?php $__errorArgs = ['profile_photo_path'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('profile_photo_path', $user?->profile_photo_path)); ?>" id="profile_photo_path" placeholder="Profile Photo Path">
            <?php echo $errors->first('profile_photo_path', '<div class="invalid-feedback" role="alert"><strong>:message</strong></div>'); ?>

        </div>

    </div>
    <div class="col-md-12 mt20 mt-2">
        <button type="submit" class="btn btn-primary"><?php echo e(__('Submit')); ?></button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\cradial\resources\views\user\form.blade.php ENDPATH**/ ?>