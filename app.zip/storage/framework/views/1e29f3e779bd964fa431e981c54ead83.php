<div>
    <!-- Select Estado -->
    <div class="mb-4">
        <label for="estado" class="block text-sm font-medium text-gray-700">Estado</label>
        <select 
            wire:model.live="selectedEstado" 
            id="estado" 
            class="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
        >
            <option value="">Seleccione un estado</option>
            <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($estado->id); ?>"><?php echo e($estado->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <!-- Select Municipio -->
    <div class="mb-4" wire:loading.remove wire:target="selectedEstado">
        <label for="municipio" class="block text-sm font-medium text-gray-700">Municipio</label>
        <select 
            wire:model.live="selectedMunicipio" 
            id="municipio" 
            class="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
            <?php if(!count($municipios)): ?> disabled <?php endif; ?> 
            >
            <option value="">Seleccione un municipio</option>
            <?php $__currentLoopData = $municipios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($municipio->id); ?>"><?php echo e($municipio->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <!-- Select Tipo Programa -->
    <div class="mb-4" wire:loading.remove wire:target="selectedMunicipio">
        <label for="tipoPrograma" class="block text-sm font-medium text-gray-700">Tipo de Programa</label>
        <select 
            wire:model="selectedTipoPrograma" 
            id="tipoPrograma" 
            class="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
            <?php if(!count($tiposPrograma)): ?> disabled <?php endif; ?>
        >
            <option value="">Seleccione un tipo de programa</option>
            <?php $__currentLoopData = $tiposPrograma; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($tipo->id); ?>"><?php echo e($tipo->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <!-- Select Emisoras -->
    <div class="mb-4" wire:loading.remove wire:target="selectedTipoPrograma">
        <label for="emisora" class="block text-sm font-medium text-gray-700">Emisora</label>
        <select 
            wire:model="selectedEmisora" 
            id="emisora" 
            class="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
            <?php if(!count($emisoras)): ?> disabled <?php endif; ?>
        >
            <option value="">Seleccione una emisora</option>
            <?php $__currentLoopData = $emisoras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emisora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($emisora->id); ?>"><?php echo e($emisora->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <!-- Select Programas de Emisora -->
    <div class="mb-4" wire:loading.remove wire:target="selectedEmisora">
        <label for="emisoraPrograma" class="block text-sm font-medium text-gray-700">Programa de la Emisora</label>
        <select 
            wire:model="selectedEmisoraPrograma" 
            id="emisoraPrograma" 
            class="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
            <?php if(!count($emisoraProgramas)): ?> disabled <?php endif; ?>
        >
            <option value="">Seleccione un programa</option>
            <?php $__currentLoopData = $emisoraProgramas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($programa->id); ?>"><?php echo e($programa->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <!-- Mostrar detalles del programa seleccionado -->
    <?php if($programaSeleccionado): ?>
        <div class="mt-6 p-4 bg-white shadow rounded-lg">
            <h3 class="text-lg font-medium text-gray-900">Detalles del Programa</h3>
            <div class="mt-2">
                <p><span class="font-semibold">Nombre:</span> <?php echo e($programaSeleccionado->nombre); ?></p>
                <p><span class="font-semibold">Emisora:</span> <?php echo e($programaSeleccionado->emisora->nombre); ?></p>
                <p><span class="font-semibold">Horario:</span> <?php echo e($programaSeleccionado->horario); ?></p>
                <p><span class="font-semibold">Descripción:</span> <?php echo e($programaSeleccionado->descripcion); ?></p>
                <!-- Puedes agregar más campos según necesites -->
            </div>
        </div>
    <?php endif; ?>

    <!-- Loading indicators -->
    <div wire:loading wire:target="selectedEstado,selectedMunicipio,selectedTipoPrograma,selectedEmisora,selectedEmisoraPrograma">
        <div class="flex justify-center items-center py-4">
            <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
            <span class="ml-2">Cargando...</span>
        </div>
    </div>

    <!-- Mensaje cuando no hay datos -->
    <?php if(count($municipios) === 0 && !is_null($selectedEstado)): ?>
        <div class="mt-4 p-3 bg-yellow-50 text-yellow-800 rounded">
            No se encontraron municipios para este estado.
        </div>
    <?php endif; ?>
    
    <?php if(count($tiposPrograma) === 0 && !is_null($selectedMunicipio)): ?>
        <div class="mt-4 p-3 bg-yellow-50 text-yellow-800 rounded">
            No se encontraron tipos de programa para este municipio.
        </div>
    <?php endif; ?>
    
    <?php if(count($emisoras) === 0 && !is_null($selectedTipoPrograma)): ?>
        <div class="mt-4 p-3 bg-yellow-50 text-yellow-800 rounded">
            No se encontraron emisoras con este tipo de programa en el municipio seleccionado.
        </div>
    <?php endif; ?>
    
    <?php if(count($emisoraProgramas) === 0 && !is_null($selectedEmisora)): ?>
        <div class="mt-4 p-3 bg-yellow-50 text-yellow-800 rounded">
            No se encontraron programas para esta emisora.
        </div>
    <?php endif; ?>
</div><?php /**PATH C:\xampp\htdocs\cradial\resources\views\livewire\selects-anidados.blade.php ENDPATH**/ ?>